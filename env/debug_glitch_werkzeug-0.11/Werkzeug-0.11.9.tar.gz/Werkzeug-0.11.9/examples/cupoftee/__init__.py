# -*- coding: utf-8 -*-
"""
    cupoftee
    ~~~~~~~~

    Werkzeug powered Teeworlds Server Browser.

    :copyright: (c) 2009 by the Werkzeug Team, see AUTHORS for more details.
    :license: BSD, see LICENSE for more details.
"""
from cupoftee.application import make_app
